package com.example.weighttracker;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

/**
 * Main screen activity that shows the user's weight history
 * and allows navigation to other parts of the app.
 */
public class main_screen extends AppCompatActivity {

    private WeightDB _weight;
    private UserModel _user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_screen);

        try {
            buildTable();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    // Inflate the menu defined in res/menu/app_menu.xml
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.app_menu, menu);
        return true;
    }

    // Handle menu item clicks
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        openSettings();
        return true;
    }

    // Navigate to settings screen
    public void openSettings() {
        startActivity(new Intent(this, UserSettings.class));
    }

    // Navigate to edit view screen
    public void openEdit(View view) {
        startActivity(new Intent(this, edit_view.class));
    }

    // Navigate to add new weight entry screen
    public void openWeightForm(View view) {
        startActivity(new Intent(this, weight_entry.class));
    }

    /**
     * Prompt the user to set a new goal weight.
     */
    public void onNewGoal(View view) {
        UserModel _user = UserModel.getUserInstance();
        WeightDB _db = WeightDB.getInstance(this);

        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);

        dialog.setTitle("Enter New Goal Weight")
                .setMessage("Your current goal is " + _user.getGoal() + " lbs. Do you want to change it?")
                .setView(input)
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        float newGoal = Float.parseFloat(input.getText().toString());
                        _user.setGoal(newGoal);
                        _db.addGoal(_user);

                        // Refresh activity to update table
                        refreshScreen();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /**
     * Build the weight history table dynamically.
     */
    private void buildTable() throws ParseException {
        _weight = WeightDB.getInstance(this);
        _user = UserModel.getUserInstance();

        List<WeightsClass> entries = new ArrayList<>();
        entries = _weight.getAllWeights(_user);

        TableLayout table = findViewById(R.id.weight_table);

        // Create header row
        TableRow header = new TableRow(this);
        header.addView(createHeaderCell("Date"));
        header.addView(createHeaderCell("Weight"));
        header.addView(createHeaderCell("Remaining"));
        table.addView(header);

        // Add rows for each entry
        for (WeightsClass entry : entries) {
            TableRow row = new TableRow(this);

            row.addView(createDataCell(entry.getDate()));
            row.addView(createDataCell(String.valueOf(entry.getWeight())));

            float remaining = entry.getWeight() - _user.getGoal();
            row.addView(createDataCell(String.valueOf(remaining)));

            table.addView(row);
        }
    }

    // Helper to create header cells
    private TextView createHeaderCell(String text) {
        TextView cell = new TextView(this);
        cell.setText(text);
        cell.setGravity(Gravity.CENTER);
        cell.setPadding(10, 10, 10, 10);
        cell.setBackgroundResource(R.color.white);
        return cell;
    }

    // Helper to create data cells
    private TextView createDataCell(String text) {
        TextView cell = new TextView(this);
        cell.setText(text);
        cell.setTextSize(14);
        cell.setGravity(Gravity.CENTER_HORIZONTAL);
        cell.setPadding(10, 10, 10, 10);
        cell.setBackgroundResource(R.color.white);
        return cell;
    }

    // Refresh the activity to reload data
    private void refreshScreen() {
        finish();
        overridePendingTransition(0, 0);
        startActivity(getIntent());
        overridePendingTransition(0, 0);
    }
}