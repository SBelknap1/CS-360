package com.example.weighttracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * UserDB manages the SQLite database for storing user login information.
 * Implements a singleton pattern so only one instance is used throughout the app.
 */
public class UserDB extends SQLiteOpenHelper {

    private static final int VERSION = 1;
    private static final String DATABASE_NAME = "users.db";
    private static UserDB _UserDB;   // singleton instance

    // Private constructor so this class can only be accessed through getInstance()
    private UserDB(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    // Singleton accessor
    public static UserDB getInstance(Context context) {
        if (_UserDB == null) {
            _UserDB = new UserDB(context.getApplicationContext());
        }
        return _UserDB;
    }

    @Override
    public void onCreate(SQLiteDatabase _db) {
        // Create the users table with username as the primary key
        _db.execSQL("CREATE TABLE users(username TEXT PRIMARY KEY, password TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase _db, int oldVersion, int newVersion) {
        // Drop the old table and recreate if schema changes
        _db.execSQL("DROP TABLE IF EXISTS users");
        onCreate(_db);
    }

    /**
     * Insert a new user into the database.
     * @param userName the username
     * @param password the password
     * @return true if insert succeeded, false otherwise
     */
    public Boolean insertUser(String userName, String password) {
        SQLiteDatabase _db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", userName);
        values.put("password", password);

        long result = _db.insert("users", null, values);
        return result != -1;
    }

    /**
     * Check if a username already exists in the database.
     * @param userName the username to check
     * @return true if found, false otherwise
     */
    public Boolean checkUserName(String userName) {
        SQLiteDatabase _db = this.getReadableDatabase();
        Cursor cursor = _db.rawQuery("SELECT * FROM users WHERE username = ?", new String[]{userName});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    /**
     * Validate a username and password combination.
     * @param userName the username
     * @param password the password
     * @return true if credentials match, false otherwise
     */
    public Boolean checkUserPassword(String userName, String password) {
        SQLiteDatabase _db = this.getReadableDatabase();
        Cursor cursor = _db.rawQuery("SELECT * FROM users WHERE username = ? AND password = ?", new String[]{userName, password});
        boolean valid = cursor.getCount() > 0;
        cursor.close();
        return valid;
    }

    /**
     * Delete a user from the database.
     * @param _user the user model containing the username
     */
    public void deleteUser(UserModel _user) {
        SQLiteDatabase _db = this.getWritableDatabase();
        _db.delete("users", "username = ?", new String[]{_user.getUserName()});
    }
}
