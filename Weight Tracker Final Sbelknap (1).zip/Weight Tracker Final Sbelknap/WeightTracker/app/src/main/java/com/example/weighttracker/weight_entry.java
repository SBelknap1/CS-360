package com.example.weighttracker;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;

import java.util.Calendar;

/**
 * weight_entry activity allows the user to add a new weight record.
 * Includes a date picker for selecting the entry date and saves the record to the database.
 */
public class weight_entry extends AppCompatActivity {

    protected EditText dateEntry;
    protected EditText weightEntry;
    protected String isoDate;   // date stored in YYYY-MM-DD format
    UserModel _user;
    WeightDB _db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_entry);

        dateEntry = findViewById(R.id.editWeightDate);
        weightEntry = findViewById(R.id.editWeightWeight);

        _user = UserModel.getUserInstance();
        _db = WeightDB.getInstance(this);

        // Open a date picker when the date field is clicked
        dateEntry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar calendar = Calendar.getInstance();
                int year = calendar.get(Calendar.YEAR);
                int month = calendar.get(Calendar.MONTH);
                int day = calendar.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        weight_entry.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                // Display date in MM-DD-YYYY format
                                dateEntry.setText((monthOfYear + 1) + "-" + dayOfMonth + "-" + year);
                                // Save ISO format for database
                                isoDate = year + "-" + (monthOfYear + 1) + "-" + dayOfMonth;
                            }
                        },
                        year, month, day
                );
                datePickerDialog.show();
            }
        });
    }

    /**
     * Navigate back to the main screen without saving.
     */
    public void openMainForm(View view) {
        Intent intent = new Intent(this, main_screen.class);
        startActivity(intent);
    }

    /**
     * Save the weight entry to the database and check for goal completion.
     */
    public void onSaveClick(View view) {
        String date = dateEntry.getText().toString();
        String sWeight = weightEntry.getText().toString();

        if (!date.isEmpty() && !sWeight.isEmpty()) {
            float weight = Float.parseFloat(sWeight);

            // Create a new weight record
            WeightsClass entry = new WeightsClass(isoDate, weight);
            boolean weightAdded = _db.addEntry(entry, _user);

            // If the user reached their goal and SMS is enabled, send a notification
            if (weight <= _user.getGoal() && _user.isTextPermission()) {
                SMSNotifications.sendLongSMS(_user.getSMSText());
            }
        }

        // Return to the main screen
        Intent intent = new Intent(this, main_screen.class);
        startActivity(intent);
    }
}