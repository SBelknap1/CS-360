package com.example.weighttracker;

import android.telephony.SmsManager;
import java.util.ArrayList;

/**
 * Utility class for sending SMS notifications.
 * Currently used to alert the user when a goal is reached.
 */
public class SMSNotifications {

    /**
     * Sends a text message to the given phone number.
     * If the message is long, it will be split into parts automatically.
     *
     * @param phoneNumber The recipient's phone number
     */
    public static void sendLongSMS(String phoneNumber) {
        // The message we want to send
        String message = "Congratulations Spencer Belknap! Goal Reached!";

        // Get the system SMS manager
        SmsManager smsManager = SmsManager.getDefault();

        // Break the message into parts if it's too long
        ArrayList<String> messageParts = smsManager.divideMessage(message);

        // Send the message as multiple parts if needed
        smsManager.sendMultipartTextMessage(phoneNumber, null, messageParts, null, null);
    }
}