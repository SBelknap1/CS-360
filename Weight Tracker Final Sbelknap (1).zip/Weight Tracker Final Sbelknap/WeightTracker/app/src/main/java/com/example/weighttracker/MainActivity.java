}package com.example.weighttracker;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

/**
 * MainActivity handles user login and registration.
 * Users can log in with existing credentials or register a new account.
 */
public class MainActivity extends AppCompatActivity {

    EditText username;
    EditText password;
    Button loginBTN;
    TextView passwordMSG;
    UserDB _db;
    UserModel validUser;
    WeightDB _weights;

    /**
     * Called when login is successful.
     * Sets up the user session and navigates to the main screen.
     */
    private void loginSuccess(View view, String _user) {
        // Initialize the weights database
        _weights = WeightDB.getInstance(this);

        // Get the singleton user model and set details
        validUser = UserModel.getUserInstance();
        validUser.setUserName(_user);
        validUser.setGoal(_weights.getGoal(validUser));

        // Navigate to the main screen
        Intent intent = new Intent(this, main_screen.class);
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username = findViewById(R.id.textUsername);
        password = findViewById(R.id.textPassword);
        loginBTN = findViewById(R.id.buttonLogin);
        passwordMSG = findViewById(R.id.passwordMessage);

        // Initialize the user database
        _db = UserDB.getInstance(this);

        // Handle login button click
        loginBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String _username = username.getText().toString();
                String _password = password.getText().toString();

                boolean userExists = _db.checkUserName(_username);
                boolean passwordMatches = _db.checkUserPassword(_username, _password);

                if (userExists) {
                    if (passwordMatches) {
                        Toast.makeText(MainActivity.this, "Login Success", Toast.LENGTH_SHORT).show();
                        loginSuccess(v, _username);
                    } else {
                        Toast.makeText(MainActivity.this, "Incorrect Password", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    // User not found, prompt to register
                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    builder.setTitle("Account Not Found")
                            .setMessage("Would you like to create a new account?")
                            .setIcon(android.R.drawable.ic_dialog_alert)
                            .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    boolean userAdded = _db.insertUser(_username, _password);
                                    if (userAdded) {
                                        Toast.makeText(MainActivity.this, "Account created", Toast.LENGTH_SHORT).show();
                                    } else {
                                        Toast.makeText(MainActivity.this, "Account creation failed", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            })
                            .setNegativeButton("No", null)
                            .show();
                }
            }
        });

        // Watch password input and enforce minimum length
        password.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() < 5) {
                    passwordMSG.setVisibility(View.VISIBLE);
                    loginBTN.setEnabled(false);
                } else {
                    passwordMSG.setVisibility(View.INVISIBLE);
                    loginBTN.setEnabled(true);
                }
            }

            @Override
            public void afterTextChanged(Editable s) { }
        });
    }
}