package com.spence.weighttracker;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

/**
 * This activity displays all weight entries in a table format.
 * Users can select entries to delete or update.
 */
public class EditWeightsActivity extends AppCompatActivity {

    private WeightDatabase db;
    private UserSession currentUser;
    private List<CompoundButton> selectedCheckBoxes = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_weights);

        try {
            loadTable();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    public void openAddEntry(View view) {
        startActivity(new Intent(this, AddWeightActivity.class));
    }

    public void openDashboard(View view) {
        startActivity(new Intent(this, DashboardActivity.class));
    }

    /**
     * Loads all weight entries and displays them in a dynamic table.
     */
    private void loadTable() throws ParseException {
        db = WeightDatabase.getInstance(this);
        currentUser = UserSession.getInstance();

        List<WeightRecord> entries = db.getAllWeights(currentUser);

        TableLayout table = findViewById(R.id.weightTable);

        // Create header row
        TableRow header = new TableRow(this);
        header.addView(createHeaderCell("Select"));
        header.addView(createHeaderCell("Date"));
        header.addView(createHeaderCell("Weight"));
        table.addView(header);

        // Create data rows
        for (WeightRecord entry : entries) {
            TableRow row = new TableRow(this);

            CheckBox checkbox = new CheckBox(this);
            checkbox.setId(entry.getId());
            checkbox.setGravity(Gravity.CENTER);
            checkbox.setPadding(10, 10, 10, 10);
            checkbox.setOnClickListener(v -> {
                CompoundButton cb = (CompoundButton) v;
                if (cb.isChecked()) {
                    selectedCheckBoxes.add(cb);
                } else {
                    selectedCheckBoxes.remove(cb);
                }
            });
            row.addView(checkbox);

            row.addView(createDataCell(entry.getDate()));
            row.addView(createDataCell(String.valueOf(entry.getWeight())));

            table.addView(row);
        }
    }

    private TextView createHeaderCell(String text) {
        TextView cell = new TextView(this);
        cell.setText(text);
        cell.setGravity(Gravity.CENTER);
        cell.setPadding(10, 10, 10, 10);
        cell.setBackgroundResource(R.color.white);
        return cell;
    }

    private TextView createDataCell(String text) {
        TextView cell = new TextView(this);
        cell.setText(text);
        cell.setTextSize(14);
        cell.setGravity(Gravity.CENTER_HORIZONTAL);
        cell.setPadding(10, 10, 10, 10);
        cell.setBackgroundResource(R.color.white);
        return cell;
    }

    /**
     * Deletes selected entries from the database.
     */
    public void deleteSelected(View view) {
        for (CompoundButton cb : selectedCheckBoxes) {
            db.deleteWeight(cb.getId());
        }
        refreshActivity();
    }

    /**
     * Prompts user to update selected entries.
     */
    public void updateSelected(View view) {
        for (CompoundButton cb : selectedCheckBoxes) {
            AlertDialog.Builder dialog = new AlertDialog.Builder(this);
            EditText input = new EditText(this);
            input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);

            dialog.setTitle("Update Weight")
                    .setMessage("Enter new weight:")
                    .setView(input)
                    .setPositiveButton("Save", (d, which) -> {
                        float newWeight = Float.parseFloat(input.getText().toString());
                        db.updateWeight(cb.getId(), newWeight, currentUser);
                        refreshActivity();
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        }
    }

    private void refreshActivity() {
        finish();
        overridePendingTransition(0, 0);
        startActivity(getIntent());
        overridePendingTransition(0, 0);
    }
}