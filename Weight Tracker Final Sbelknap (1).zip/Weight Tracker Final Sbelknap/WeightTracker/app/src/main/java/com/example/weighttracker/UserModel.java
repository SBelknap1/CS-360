package com.example.weighttracker;

/**
 * UserModel represents the currently logged-in user.
 * This class is a singleton so only one user session exists at a time.
 * Stores username, goal weight, SMS settings, and permissions.
 */
public class UserModel {

    private String userName;
    private float goal = 0;              // default goal weight
    private boolean textPermission = false;
    private String SMSText = "0000000000"; // default phone number
    private static UserModel _loggedUser;  // singleton instance

    /**
     * Returns the single instance of UserModel.
     * If it doesn't exist yet, it will be created.
     */
    public static UserModel getUserInstance() {
        if (_loggedUser == null) {
            _loggedUser = new UserModel();
        }
        return _loggedUser;
    }

    // Private constructor prevents direct instantiation
    private UserModel() { }

    // --- Getters and Setters ---

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public float getGoal() {
        return goal;
    }

    public void setGoal(float goal) {
        this.goal = goal;
    }

    public boolean isTextPermission() {
        return textPermission;
    }

    public void setTextPermission(boolean textPermission) {
        this.textPermission = textPermission;
    }

    public String getSMSText() {
        return SMSText;
    }

    public void setSMSText(String SMSText) {
        this.SMSText = SMSText;
    }
}
