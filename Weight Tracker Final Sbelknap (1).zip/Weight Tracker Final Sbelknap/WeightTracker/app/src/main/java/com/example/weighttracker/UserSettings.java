package com.example.weighttracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;

/**
 * UserSettings allows the user to update notification preferences,
 * save their phone number for SMS alerts, or delete their account.
 */
public class UserSettings extends AppCompatActivity {

    private Button deleteAccount;
    private UserDB _userDB;
    private WeightDB _weights;
    private UserModel _user;
    private CompoundButton _switch;
    private EditText phone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_settings);

        // Get the current user session
        _user = UserModel.getUserInstance();

        // Initialize phone number field with saved value
        phone = findViewById(R.id.editTextPhone);
        phone.setText(_user.getSMSText());

        // Delete account button
        deleteAccount = findViewById(R.id.buttonDelAccount);

        // Notification toggle switch
        _switch = findViewById(R.id.notifications);
        _switch.setChecked(_user.isTextPermission());
        _switch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                _user.setTextPermission(isChecked);
            }
        });
    }

    /**
     * Deletes the current user's account and weight records.
     * Forces the app to close after deletion.
     */
    public void deleteUserAccounts(View view) {
        _userDB = UserDB.getInstance(this);
        _weights = WeightDB.getInstance(this);
        _user = UserModel.getUserInstance();

        // Remove user data from both databases
        _weights.deleteUser(_user);
        _userDB.deleteUser(_user);

        // Close the app completely
        this.finishAffinity();
        System.exit(0);
    }

    /**
     * Saves the phone number entered by the user and returns to the main screen.
     */
    public void openMain(View view) {
        phone = findViewById(R.id.editTextPhone);
        String sPhone = phone.getText().toString();

        if (sPhone != null && !sPhone.isEmpty()) {
            _user.setSMSText(sPhone);
        }

        Intent intent = new Intent(this, main_screen.class);
        startActivity(intent);
    }
}