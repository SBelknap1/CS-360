package com.example.weighttracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * WeightDB manages the SQLite database for weight entries and goals.
 * Implements a singleton pattern so only one instance is used throughout the app.
 */
public class WeightDB extends SQLiteOpenHelper {

    private static final int VERSION = 1;
    private static final String DATABASE_NAME = "weights.db";
    private static WeightDB _weightDB;   // singleton instance

    // Private constructor to enforce singleton
    private WeightDB(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    // Singleton accessor
    public static WeightDB getInstance(Context context) {
        if (_weightDB == null) {
            _weightDB = new WeightDB(context.getApplicationContext());
        }
        return _weightDB;
    }

    @Override
    public void onCreate(SQLiteDatabase _db) {
        // Create table for weight entries
        _db.execSQL("CREATE TABLE weights(_ID INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, date TEXT, weight FLOAT)");

        // Create table for user goals
        _db.execSQL("CREATE TABLE goals(username TEXT PRIMARY KEY, goal FLOAT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase _db, int oldVersion, int newVersion) {
        _db.execSQL("DROP TABLE IF EXISTS weights");
        _db.execSQL("DROP TABLE IF EXISTS goals");
        onCreate(_db);
    }

    /**
     * Add a new weight entry for a user.
     */
    public Boolean addEntry(WeightsClass _entry, UserModel _user) {
        SQLiteDatabase _db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", _user.getUserName());
        values.put("date", _entry.getDate());
        values.put("weight", _entry.getWeight());

        long id = _db.insert("weights", null, values);
        return id != -1;
    }

    /**
     * Remove a weight entry by ID.
     */
    public void removeEntry(Integer entryID) {
        SQLiteDatabase _db = this.getWritableDatabase();
        _db.delete("weights", "_id = ?", new String[]{String.valueOf(entryID)});
    }

    /**
     * Update an existing weight entry.
     */
    public Boolean updateEntry(int _id, float weight, UserModel _user) {
        SQLiteDatabase _db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", _user.getUserName());
        values.put("weight", weight);

        int rows = _db.update("weights", values, "_id = ?", new String[]{String.valueOf(_id)});
        return rows > 0;
    }

    /**
     * Add or update a user's goal.
     */
    public void addGoal(UserModel _user) {
        SQLiteDatabase _db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", _user.getUserName());
        values.put("goal", _user.getGoal());

        // Check if goal already exists
        Cursor cursor = _db.rawQuery("SELECT * FROM goals WHERE username = ?", new String[]{_user.getUserName()});
        boolean goalExists = cursor.getCount() > 0;
        cursor.close();

        if (!goalExists) {
            _db.insert("goals", null, values);
        } else {
            _db.updateWithOnConflict("goals", values, "username = ?", new String[]{_user.getUserName()}, SQLiteDatabase.CONFLICT_REPLACE);
        }
    }

    /**
     * Retrieve the goal for a given user.
     */
    public float getGoal(UserModel _user) {
        SQLiteDatabase _db = this.getReadableDatabase();
        float goalValue = 0;

        Cursor cursor = _db.rawQuery("SELECT goal FROM goals WHERE username = ?", new String[]{_user.getUserName()});
        if (cursor.moveToFirst()) {
            goalValue = cursor.getFloat(0);
        }
        cursor.close();

        return goalValue;
    }

    /**
     * Get all weight entries for a user, formatted for display.
     */
    public List<WeightsClass> getAllWeights(UserModel _user) throws ParseException {
        List<WeightsClass> allEntry = new ArrayList<>();
        SQLiteDatabase _db = this.getReadableDatabase();

        Cursor cursor = _db.rawQuery("SELECT * FROM weights WHERE username = ? ORDER BY date", new String[]{_user.getUserName()});

        if (cursor.moveToFirst()) {
            do {
                int ID = cursor.getInt(0);
                String date = cursor.getString(2);

                // Convert ISO date to MM-dd-yyyy
                String prettyDate = date;
                try {
                    SimpleDateFormat isoFormat = new SimpleDateFormat("yyyy-MM-dd");
                    Date parsedDate = isoFormat.parse(date);
                    SimpleDateFormat displayFormat = new SimpleDateFormat("MM-dd-yyyy");
                    prettyDate = displayFormat.format(parsedDate);
                } catch (ParseException e) {
                    e.printStackTrace();
                }

                float userWeight = cursor.getFloat(3);

                // Create entry object and add to list
                WeightsClass newEntry = new WeightsClass(ID, prettyDate, userWeight);
                allEntry.add(newEntry);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return allEntry;
    }

    /**
     * Delete all records for a given user (weights and goals).
     */
    public void deleteUser(UserModel _user) {
        SQLiteDatabase _db = this.getWritableDatabase();
        _db.delete("goals", "username = ?", new String[]{_user.getUserName()});
        _db.delete("weights", "username = ?", new String[]{_user.getUserName()});
    }
}