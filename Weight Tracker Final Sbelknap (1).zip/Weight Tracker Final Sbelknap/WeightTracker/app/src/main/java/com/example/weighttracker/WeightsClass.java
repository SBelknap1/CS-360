package com.example.weighttracker;

/**
 * WeightsClass represents a single weight entry in the database.
 * Stores the entry ID, date, and weight value.
 */
public class WeightsClass {

    private int ID;        // unique identifier for the entry
    private String date;   // date of the entry (formatted for display)
    private float weight;  // weight value recorded

    /**
     * Constructor used when retrieving an entry with an ID from the database.
     */
    public WeightsClass(int ID, String date, float weight) {
        this.ID = ID;
        this.date = date;
        this.weight = weight;
    }

    /**
     * Constructor used when creating a new entry before it has an ID.
     */
    public WeightsClass(String date, float weight) {
        this.date = date;
        this.weight = weight;
    }

    // --- Getters and Setters ---

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public float getWeight() {
        return weight;
    }

    public void setWeight(float weight) {
        this.weight = weight;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }
}